# Project instructions

## Frontend design

Always invoke the `frontend-design` skill proactively before creating or
reshaping any UI in this repo (index.html, styles, layout, copy) — even if
the user does not explicitly ask for it. Apply its guidance automatically
whenever visual or design decisions are being made.
